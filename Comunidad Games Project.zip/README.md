# HelbreatH Ultra — Sitio de comunidad

Sitio web oficial de **HelbreatH Ultra**, servidor privado de Helbreath. Página única (landing) con noticias, rankings, estado del servidor en vivo y descarga del cliente.

![Estado](https://img.shields.io/badge/servidor-online-2ecf8f) ![Tipo](https://img.shields.io/badge/MMORPG-medieval-caa44a)

## ✨ Características

- **Hero con logo animado** (SVG + CSS, sin dependencias) en formato horizontal.
- **Contador de jugadores online** en vivo con variación dinámica.
- **Noticias** destacadas, eventos y parches.
- **Rankings** con pestañas: Enemy Kills (EKs), Exp/Rebirths y Guilds.
- **Guerra de naciones** (Aresden vs Elvine) con barra de control y estadísticas.
- **Sección de descarga** del cliente con requisitos mínimos.
- **Navegación responsive** con menú desplegable y drawer móvil.
- Paleta **verde inglés + violeta oscuro**, tipografía Cinzel / Barlow.

## 🗂️ Estructura

```
.
├── Comunidad.html      # Sitio completo (HTML + CSS + JS en un solo archivo)
└── README.md
```

Todo el sitio vive en `Comunidad.html`: estilos en `<style>`, lógica (rankings, contador, menús) en `<script>` al final, y el logo como `<symbol>` SVG reutilizable. No requiere build ni instalación.

## 🚀 Uso

Abre `Comunidad.html` en cualquier navegador moderno. Para publicarlo:

- **GitHub Pages:** Settings → Pages → Branch `main` → carpeta raíz. (Opcional: renombra `Comunidad.html` a `index.html` para que sea la página por defecto.)
- **Hosting estático:** sube el archivo a Netlify, Vercel, o cualquier servidor web.

## 🎨 Personalización

| Qué | Dónde |
|-----|-------|
| Colores (verde / violeta / oro) | variables `:root` al inicio del `<style>` |
| Nombre / textos | marcado HTML de cada sección |
| Datos de rankings | objeto `data` en el `<script>` |
| Logo | `<symbol id="hbEmblem">` y bloque `.hb-wrap` |
| Contador de online | función `tick()` en el `<script>` |

## 📄 Licencia

Proyecto de fans sin fines de lucro. No afiliado a marcas comerciales.
